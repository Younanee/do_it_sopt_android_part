package com.sopt_nyh.sub_seminar002_example

data class KakaoTalkRoomData(var title : String,
                             var content : String,
                             var person_cnt : Int,
                             var time : String)