package com.sopt_nyh.sub_seminar002_example.data

data class MemoData(
        var title : String,
        var content : String
)


data class User(
        val name : String,
        var age : Int
)

