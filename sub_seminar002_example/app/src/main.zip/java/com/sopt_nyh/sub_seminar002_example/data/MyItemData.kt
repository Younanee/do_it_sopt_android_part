package com.sopt_nyh.sub_seminar002_example.data

data class MyItemData(
        val counter : Int,
        val islike : Boolean
)